##############################
[Polo360 PSD Template]
Designed by: Viv Singh
Exclusively for: Hongkiat.com
##############################

You can to use this freebie for both private and commercial project freely. However, you are not allow to re-sell or generate profit whatsoever out of it.

This freebie should not be offered for free downloading from other websites other than it's developer's website and Hongkiat.com.

Thank you for downloading,
Hongkiat.com